"""File transfer server - Stage 1: receive one file, then exit.

Protocol (our own tiny "language" between client and server):
    line 1: file name, ending in a newline
    line 2: file size in bytes, ending in a newline
    then:   exactly that many raw bytes of file data
"""
import os
import socket

HOST = "0.0.0.0"      # listen on all network interfaces
PORT = 5001
SAVE_DIR = "received"


def recv_line(conn):
    """Read bytes until a newline and return them as text."""
    data = b""
    while not data.endswith(b"\n"):
        chunk = conn.recv(1)
        if not chunk:
            raise ConnectionError("connection closed before the header was complete")
        data += chunk
    return data.decode().strip()


def main():
    os.makedirs(SAVE_DIR, exist_ok=True)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen()
        print(f"Listening on port {PORT} ...")

        conn, addr = server.accept()          # waits here until a client connects
        with conn:
            print("Connected:", addr)

            # basename() strips folders, so a client can't write outside SAVE_DIR
            filename = os.path.basename(recv_line(conn))
            size = int(recv_line(conn))

            received = 0
            with open(os.path.join(SAVE_DIR, filename), "wb") as f:
                while received < size:
                    # TCP is a stream: recv() may return less than we asked for
                    chunk = conn.recv(min(4096, size - received))
                    if not chunk:
                        break
                    f.write(chunk)
                    received += len(chunk)

            print(f"Saved {filename}: {received}/{size} bytes")


main()
