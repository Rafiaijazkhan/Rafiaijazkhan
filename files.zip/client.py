"""File transfer client - Stage 1: send one file to the server.

Usage: python client.py <host> <file>
"""
import os
import socket
import sys

PORT = 5001


def main():
    if len(sys.argv) != 3:
        print("Usage: python client.py <host> <file>")
        return

    host, path = sys.argv[1], sys.argv[2]
    size = os.path.getsize(path)

    with socket.create_connection((host, PORT)) as s:
        # header first: file name, then size, each on its own line
        s.sendall(f"{os.path.basename(path)}\n{size}\n".encode())

        # then the file itself, 4 KB at a time
        with open(path, "rb") as f:
            while chunk := f.read(4096):
                s.sendall(chunk)

    print(f"Sent {path} ({size} bytes)")


main()
